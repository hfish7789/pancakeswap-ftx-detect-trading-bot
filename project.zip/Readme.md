run method:
 command: npm install
 command: node index
 Next, please visit this page:
 http://localhost:3000